package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //targil 1
        int num1;
        System.out.println("enter a number");
        Scanner input = new Scanner(System.in);
        num1 = input.nextInt();
        System.out.println(prime(num1));

        //targil 2
        for (int i=2;i<=1000;i++){
            if (prime(i)){
                System.out.println(i);
            }
        }
        //targil 3
        System.out.println("enter a number");
        num1 = input.nextInt();
        System.out.println(sum(num1));
    }
    public static boolean prime (int num){
    boolean prime = true;
        for (int i = 2; i < num; i++) {
        if (num % i == 0) {
            prime = false;
        }
    }
        return prime;
    }
    public static int sum (int num){
        int sum = 0;
        while (num>0){
            sum+=num%10;
            num/=10;
        }
        return sum;
    }
}